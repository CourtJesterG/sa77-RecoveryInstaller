rm extract.sh
find ./ | cpio --quiet -H newc -o > recovery-cwm.cpio
xz -ze recovery-cwm.cpio
cp recovery-cwm.cpio.xz ../
cd ../
rm -rf test